package org.Group1.SELENIUM1;

import org.testng.annotations.Test;

public class SELENIUM_First TC {
  @Test
  public void f() {
  }
}
